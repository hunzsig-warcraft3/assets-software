# /*
#  *  YDTrigger专用宏
#  *  
#  *  全局变量部分
#  *
#  *  By actboy168
#  *
#  */
#
#ifndef INCLUDE_GLOBALS_H
#define INCLUDE_GLOBALS_H
#
#endif
