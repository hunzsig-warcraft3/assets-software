return {
    commit = '69266a77536af75701cfbadf607691faed162abd',
    date = 'Mon Aug 20 10:56:20 2018 +0800',
}